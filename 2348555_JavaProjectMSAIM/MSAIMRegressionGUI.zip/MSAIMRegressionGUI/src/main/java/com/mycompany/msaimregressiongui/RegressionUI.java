/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.msaimregressiongui;

/**
 *
 * @author SATYAM 2348555
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RegressionUI extends JFrame {

    private JButton addVariableButton;
    private JButton calculateButton;
    private JButton saveToDatabaseButton;
    private JButton knowMoreButton;
    private JButton predictButton;
    private JButton showGraphButton;
    private JTextArea resultTextArea;
    private JTextField predictInputField;
    private JTable variableTable;

    private DefaultTableModel variableTableModel;
    private SimpleLinearRegression linearRegression;

    public RegressionUI() {
        initComponents();
        initKnowMoreButton();
    }
    
    private void initComponents() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("Linear Regression Analysis");
        setSize(800, 600);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(236, 244, 214));

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(38, 80, 115));
        JLabel titleLabel = new JLabel("Linear Regression Analysis", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
        titleLabel.setForeground(new Color(135, 206, 250));
        headerPanel.add(titleLabel);

        JPanel centerPanel = new JPanel(new BorderLayout());

        variableTableModel = new DefaultTableModel();
        variableTableModel.addColumn("X Variable");
        variableTableModel.addColumn("Y Variable");

        variableTable = new JTable(variableTableModel);
        variableTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        JScrollPane variableScrollPane = new JScrollPane(variableTable);
        variableScrollPane.setPreferredSize(new Dimension(400, 200));

        JPanel variableInputPanel = new JPanel(new BorderLayout());
        variableInputPanel.setBackground(new Color(191,207,231));
        variableInputPanel.add(new JLabel("Variable Input"), BorderLayout.NORTH);
        variableInputPanel.add(variableScrollPane, BorderLayout.CENTER);

        centerPanel.add(variableInputPanel, BorderLayout.WEST);

        JPanel buttonsPanel = new JPanel(new GridLayout(4, 1, 0, 10));
        buttonsPanel.setBackground(new Color(191,207,231));
        addVariableButton = new JButton("Add Variable");
        addVariableButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addVariable();
            }
        });
        customizeButton(addVariableButton);

        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateRegression();
            }
        });
        customizeButton(calculateButton);

        saveToDatabaseButton = new JButton("Save to Database");
        saveToDatabaseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveToDatabase();
            }
        });
        customizeButton(saveToDatabaseButton);

        buttonsPanel.add(addVariableButton);
        buttonsPanel.add(calculateButton);
        buttonsPanel.add(saveToDatabaseButton);

        centerPanel.add(buttonsPanel, BorderLayout.CENTER);

        JPanel resultPanel = new JPanel(new BorderLayout());

        
        JPanel regressionResultPanel = new JPanel(new BorderLayout());
        regressionResultPanel.setBackground(new Color(191,207,231));
        regressionResultPanel.setBorder(BorderFactory.createTitledBorder("Regression Result"));
        resultTextArea = new JTextArea(6, 40);
        resultTextArea.setEditable(false);
        regressionResultPanel.add(new JScrollPane(resultTextArea), BorderLayout.CENTER);

        JPanel predictPanel = new JPanel(new FlowLayout());
        predictPanel.setBackground(new Color(191, 207, 231));
        predictPanel.setBorder(BorderFactory.createTitledBorder("Predict"));
        predictInputField = new JTextField(10);
        predictButton = new JButton("Predict Y");
        predictButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                predict();
            }
        });
        predictPanel.add(new JLabel("Enter X value:"));
        predictPanel.add(predictInputField);
        predictPanel.add(predictButton);

        JPanel graphPanel = new JPanel(new FlowLayout());
        graphPanel.setBackground(new Color(191, 207, 231));
        graphPanel.setBorder(BorderFactory.createTitledBorder("Graph"));
        showGraphButton = new JButton("Show Graph");
        showGraphButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showGraph();
            }
        });
        graphPanel.add(showGraphButton);

        
        resultPanel.add(regressionResultPanel, BorderLayout.NORTH);
        resultPanel.add(predictPanel, BorderLayout.CENTER);
        resultPanel.add(graphPanel, BorderLayout.SOUTH);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(resultPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void initKnowMoreButton() {
        knowMoreButton = new JButton("Know more about regression");
        knowMoreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                redirectToRegressionWebpage();
            }
        });
        customizeButton(knowMoreButton);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(191, 207,231));
        buttonPanel.add(knowMoreButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void customizeButton(JButton button) {
        button.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        button.setBackground(new Color(120,214,198));
        button.setForeground(new Color(38, 80, 115));
    }

    private void addVariable() {
        if (variableTableModel.getRowCount() < 100) {
            variableTableModel.addRow(new Object[]{"", ""});
        } else {
            JOptionPane.showMessageDialog(this, "Cannot add more than 100 variables.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void calculateRegression() {
        int rowCount = variableTableModel.getRowCount();
        List<Double> xValues = new ArrayList<>();
        List<Double> yValues = new ArrayList<>();

        for (int i = 0; i < rowCount; i++) {
            Object xObj = variableTableModel.getValueAt(i, 0);
            Object yObj = variableTableModel.getValueAt(i, 1);

            if (xObj != null && yObj != null) {
                String xString = xObj.toString().trim();
                String yString = yObj.toString().trim();

                if (!xString.isEmpty() && !yString.isEmpty()) {
                    try {
                        double x = Double.parseDouble(xString);
                        double y = Double.parseDouble(yString);
                        xValues.add(x);
                        yValues.add(y);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "Invalid numeric input. Please enter numeric values for X and Y.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }
        }

        linearRegression = new SimpleLinearRegression(xValues, yValues);
        double m = linearRegression.getSlope();
        double c = linearRegression.getIntercept();
        double rSquared = linearRegression.getRSquared();
        double mse = linearRegression.getMeanSquaredError();
        double coefficient = linearRegression.getCoefficient();
        double intercept = linearRegression.getIntercept();

        String resultMessage = String.format("Slope (m): %.4f\nIntercept (c): %.4f\nR^2: %.4f\nMSE: %.4f\n" +
                "Coefficient: %.4f\nIntercept: %.4f", m, c, rSquared, mse, coefficient, intercept);

        resultTextArea.setText(resultMessage);
    }

    private void predict() {
        String xString = predictInputField.getText().trim();

        if (!xString.isEmpty()) {
            try {
                double x = Double.parseDouble(xString);
                double predictedY = linearRegression.predictY(x);
                JOptionPane.showMessageDialog(this, "Predicted Y: " + predictedY, "Prediction", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid numeric input. Please enter a numeric value for X.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please enter a value for X.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showGraph() {
        //next version
        JOptionPane.showMessageDialog(this, "Graph functionality is not implemented in this version.", "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    private void saveToDatabase() {
        String resultText = resultTextArea.getText();
        double slope = linearRegression.getSlope();
        double intercept = linearRegression.getIntercept();
        double rSquared = linearRegression.getRSquared();
        double meanSquaredError = linearRegression.getMeanSquaredError();
        double coefficient = linearRegression.getCoefficient();

        String url = "jdbc:mysql://localhost:3307/regression_db";
        String user = "user";
        String password = "";

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            String sql = "INSERT INTO regression_results (slope, intercept, r_squared, mean_squared_error, coefficient, result_text) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setDouble(1, slope);
                statement.setDouble(2, intercept);
                statement.setDouble(3, rSquared);
                statement.setDouble(4, meanSquaredError);
                statement.setDouble(5, coefficient);
                statement.setString(6, resultText);

                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(this, "Result saved to database successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to save result to database.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database connection error.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void redirectToRegressionWebpage() {
        String servletUrl = "http://localhost:8080/regression_webpage/Regression.jsp";
        try {
            Desktop.getDesktop().browse(new URI(servletUrl));
        } catch (IOException | URISyntaxException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }

            RegressionUI regressionUI = new RegressionUI();
            regressionUI.setDefaultCloseOperation(regressionUI.EXIT_ON_CLOSE);
            regressionUI.setVisible(true);
        });
    }

    static class SimpleLinearRegression {

        private List<Double> xValues;
        private List<Double> yValues;

        public SimpleLinearRegression(List<Double> xValues, List<Double> yValues) {
            if (xValues.size() != yValues.size()) {
                throw new IllegalArgumentException("Input lists must have the same size");
            }
            this.xValues = xValues;
            this.yValues = yValues;
        }

        public double getSlope() {
            int n = xValues.size();
            double sumXY = 0;
            double sumX = 0;
            double sumY = 0;
            double sumXSquare = 0;

            for (int i = 0; i < n; i++) {
                double x = xValues.get(i);
                double y = yValues.get(i);
                sumXY += x * y;
                sumX += x;
                sumY += y;
                sumXSquare += x * x;
            }

            return (n * sumXY - sumX * sumY) / (n * sumXSquare - sumX * sumX);
        }

        public double getIntercept() {
            int n = xValues.size();
            double sumX = 0;
            double sumY = 0;
            double sumXSquare = 0;

            for (int i = 0; i < n; i++) {
                double x = xValues.get(i);
                double y = yValues.get(i);
                sumX += x;
                sumY += y;
                sumXSquare += x * x;
            }

            double slope = getSlope();

            return (sumY - slope * sumX) / n;
        }

        public double getRSquared() {
            int n = xValues.size();
            double sumY = 0;
            double sumYSquare = 0;
            double sumPredictedYSquare = 0;
            double sumPredictedY = 0;

            double slope = getSlope();
            double intercept = getIntercept();

            for (int i = 0; i < n; i++) {
                double y = yValues.get(i);
                double predictedY = slope * xValues.get(i) + intercept;

                sumY += y;
                sumYSquare += y * y;
                sumPredictedYSquare += predictedY * predictedY;
                sumPredictedY += predictedY;
            }

            double rSquared = 1 - ((n * sumYSquare - sumY * sumY) / (n * sumPredictedYSquare - sumPredictedY * sumPredictedY));
            return rSquared;
        }

        public double getMeanSquaredError() {
            int n = xValues.size();
            double sumSquaredError = 0;

            double slope = getSlope();
            double intercept = getIntercept();

            for (int i = 0; i < n; i++) {
                double y = yValues.get(i);
                double predictedY = slope * xValues.get(i) + intercept;
                sumSquaredError += Math.pow(y - predictedY, 2);
            }

            return sumSquaredError / n;
        }

        public double getCoefficient() {
            return getSlope();
        }

        public double predictY(double x) {
            double slope = getSlope();
            double intercept = getIntercept();
            return slope * x + intercept;
        }
    }
}
